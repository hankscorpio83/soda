
               SODA Off-Road Racing (v1.01)
			    README
	               10/1/97

_______________________________________________________________________
***********************************************************************
About This Document:

Thanks you for purchasing SODA Off-Road Racing. 

This document contains last-minute information about SODA and 
other information about the program not found in the Help Files.  This 
README file includes information that pertains to general problems and 
questions you may have concerning the game or your computer. Should you 
experience any problems with SODA, please refer to this file 
for addition help on answering questions about the game and solving 
technical difficulties.

***********************************************************************


          	          TABLE OF CONTENTS

		       I] MINIMUM REQUIREMENTS
		      II] HOW TO START SODA
		     III] HOW TO PLAY SODA
		      IV] KNOWN PROBLEMS



I] MINIMUM REQUIREMENTS
=======================================================================

MINIMUM CONFIGURATION

	- Operating System: Windows 95 
	- Pentium 90 Mhz processor (P-90) or faster
	- 16 MB RAM
	- Double speed CD-ROM drive (MPC 2 Compliant)
	- 16-bit Sound Card (Windows 95 and DirectX3 Compatible)
	- VLB/PCI SVGA DirectX3 Compatible Graphics Adapter
	- Hard Disk (60MB) plus space for DirectX Drivers
	- Keyboard (not recommended for driving... get a joystick!)

	
RECOMMENDED CONFIGURATION

	- Pentium 133 Mhz processor (P-133) or faster
	- Rendition based 3D-accelerator board with 4 MB video RAM
	- 24 MB System RAM	
	- Steering Wheel/Pedals (or at least a joystick)


II] HOW TO START SODA
=======================================================================



INSTALLATION
------------
Insert the CD-ROM containing SODA Off-Road Racing into your computer's 
CD-ROM drive. Start the installation process as follows:

    1. Click the "Start" button on the Windows 95 task bar. 
 
    2. Choose "Run..." from the displayed menu. 
 
    3. Type the letter of your CD-ROM drive, followed by ":\setup". 
       For example, if your CD-ROM is drive D, type "D:\setup". 
 
    4. Click the "OK" button to start the installation program.


Follow the instructions provided by the installation program.  


RENDITION SUPPORT
-----------------
This version of SODA Off-Road Racing has direct support for
several Rendition 3D-Accelerator boards. Note that SODA requires 
the 2.0 series of display drivers. A "last resort" set of drivers is 
included on the SODA CD, but you may need to get your vendor's 
2.0 display drivers. The following boards are supported:

	- Screamin' 3D from Sierra On-Line
	- Intense 3D 100 from Intergraph
	- Total 3D from Canopus
	- 3D Blaster PCI from Creative Labs
	- Royal Flush from Miro

SODA will auto-detect the accelerator board once the correct drivers 
are installed. When one of the above boards is detected, a 
"Rendition Ready" logo appears on the title screen, to let you know 
the game is running using 3D Acceleration.  To disable 3D-Accelerator 
support in SODA, run offroad.exe with the /S command line option. 
If the "Rendition Ready" logo does not appear on the title screen, 
SODA is not using any 3D acceleration support.

To install the Rendition display drivers from the SODA CD:

1. Click the Start button on the task bar, and choose Settings then 
   Control Panel.
	
2. From the Control Panel select Display.
	
3. From the Settings tab push the Change Display Type button. 
	
4. Under Adapter Type press Change.
	
5. Press the Have Disk button
	
6. Enter the drive letter of the CD-ROM, followed by "\rend_v1", 
   or "\rend_v2" (depending on the type of board you have,
   eiter a Verite 1000 PCI or a Verite 2200 PCI) then Choose OK. 
	
7. Select the Rendition Verite 1000 PCI RRedline drivers, 
   or the Verite 2200 PCI RRedline drivers (depending on the type
   of board you have) and push the OK button. 
	
8. From the Change Display Type dialog push the Close button. From 
   the Display Properties dialog push the Close button. Select Yes 
   when asked to restart the computer. 




III] HOW TO PLAY SODA
=======================================================================

STARTING THE GAME
-----------------
First, close all other applications running on your system. Windows 95
is a multi-tasking environment, and running other applications while
playing SODA Off-Road Racing will definitely reduce performance. 

Two icons are installed for launching SODA Off-Road Racing, one for 
Full-Screen Mode and the other for Windowed Mode. Full-Screen Mode is 
recommended because it supports 3D-Acceleration, it exhibits a better 
frame-rate on many systems, and it is more immersive.  The Windowed 
Mode (/W on the command line) is mainly provided to allow the game to 
run on some systems where Full-Screen Mode cannot work due to 
incompatibilities with the video card.

If a compatible 3D-accelerator board is detected, SODA will display the 
Rendition Ready logo while starting to let you know it will use the 
accelerator board. If a compatible board is not detected, the logo 
will not be displayed.  If problems are encountered when using a 
certain 3D-Accelerator board, the use of the acceleration features can 
be disabled by launching offroad.exe with the /S option on the command 
line. 


SCREEN NAVIGATION
-----------------
Most menu, options, and record screens can be controlled by keyboard, 
mouse, joystick, or even steering wheel/pedals. Only a few name entry 
controls require the use of a keyboard. The following table describes 
the control options:


  Action		    Keyboard           Joystick	       Mouse
-----------------------------------------------------------------------|
|Selecting    |     Tab key advances    Button #2 	         Point   |
|Controls     |	  to the next 	    advances to 	          and    |
|             |     control.		    the next control.      click.  |
|             |				                                   |
|Selecting    |	  Up/Down arrow keys. up/down		                 |
|Menu Items   |	  Enter to select.    Button #1 to select.   Point   |
|             |                                                 and    |
|             |					       	         click   |	
|             |						                       |
|Buttons      |     Use the Spacebar    Button #1 to 	         Point   |
|             |     to activate the     activate the	          and    |
|	        |	  selected button.    selected button.       click.  |
|	        | 						                       |
|Lists 	  |     Up/Down Arrow keys  up/down or left/right  Point   |
|             |     for vertical lists.			          and    |
|             |     Left/Right Arrow 			         click.  |
|             |     keys for horizontal   		                 |
|             |     lists.					                 |
-----------------------------------------------------------------------|

The mouse is recommended. Also, on many screens, two shortcuts are 
available - the Esc key will go to the previous screen (cancelling changes), 
and Enter key will advance to the next screen (applying changes).


JOYSTICK, STEERING WHEEL, AND PEDALS SETUP
-----------------------------------------
NOTE: You must first configure your controller in the joystick portion
of the Windows 95 control panel before it will be available in the game.
But, the joystick calibration available from within the Windows 95 
Control-Panel is not recognized by SODA Off-Road Racing. You need to use 
the calibration procedure described below once the joystick has been 
properly configured. 

Before proceeding, and certainly before racing, you want to calibrate your 
controls. All analog input devices such as joysticks, steering wheels, and 
pedals need to be calibrated in order to work correctly with computer games. 
An incorrectly calibrated joystick may make it difficult or impossible to 
control your vehicle.  This calibration procedure should be repeated 
regularly (at least once a week), especially if any control difficulties 
arise.

At start-up, if the game detects that the joystick is too far from center, 
it will automatically bring you to the calibration screen, so you can 
perform the necessary recalibration. 

To calibrate your joystick, steering wheel, and/or pedals from the Main 
Menu Screen:

1. Select Options from the Main Menu Screen. 

2. The Options Screen has a list of 4 pages along the bottom. Select the 
   Control Options page. 

3. On the Control Options Screen, push the Calibrate button. 

4. Slowly move all of the connected joysticks, steering wheels, and pedals 
   to their maximum extents, then center them (for pedals this means 
   release the brake and accelerator).  If you move the controls too quickly 
   while calibrating it may result in a bad calibration, requiring the entire 
   process to be repeated, so just be gentle.

5. If you are sure the calibration worked, push the OK button. However, we 
   recommend that you instead push the Test button, and manually inspect the 
   calibration, just to be sure. On the Test Screen you can actually see if 
   your joystick is working and calibrated correctly. If you are satisfied 
   with the calibration you can choose the OK button. If you wish to repeat 
   the calibration, simply choose to Restart the calibration procedure. The 
   Test Screen will also reveal any joystick malfunctions, such as the 
   inability to return to center reliably or jumpy performance caused by wear 
   and use. Both of these conditions can make it harder to drive. We recommend 
   using high quality joysticks such as those listed in the installation 
   instructions.

CONTROL SETUP
-------------
From the Control Options Screen you may configure the controls you want to 
use to drive and to change the camera view. Simply press the button for the 
desired action, and then provide an example input. For example, to use the 
joystick as the accelerator pedal, push the Accelerate button, and then push  
forward on the joystick. The words Joystick #1 Up should appear next to the 
Accelerate button, confirming your selection.   If a control is already selected 
for another action, it cannot be reselected. Also, some keys cannot be used for 
driving actions because they are already assigned for other (non-driving) 
commands, or because they are not standard keys available on all keyboards.

QUICK START
-----------
Before your first race, at least make sure you have calibrated your joystick, 
steering wheel, and/or pedals, as described in the previous sections.   Then, 
proceed as follows:

1. Select the Single Races command from the Main Menu. This mode is for racing 
   one race at a time, and is good for practicing racing before trying to win 
   a championship series.
 
2. Selecting Single Races will bring up the Vehicle Select screen. The Vehicle 
   Select screen is where you choose which type of vehicle you want to race. 
   Select the two-wheel drive buggy.
 
3. After clicking on the buggy, click the right arrow button on the lower left of 
   the screen. This is called the Next Button, and advances you one screen closer 
   to racing. This takes you to the Track Select Screen. This is where you select 
   the racing environment and then the race track. Along the bottom of the screen, 
   select the Country environment. Then, along the top left of the screen, 
   select the track "Cliffs Of Fear" .  
 
4. After selecting the track, enter the Garage to make sure your vehicle is setup 
   for the race. Enter the garage by pressing the Wrench Button on the bottom left 
   of the Track Select Screen. Once in the garage, set the tires to "Deep Tread" or
   maybe "Normal Tread" because Cliffs Of Fear has a lot of mud. Then set the 
   transmission as you desire (Automatic or Manual), but at first we suggest using 
   an automatic transmission because it is simpler to control.  Don't bother 
   adjusting the suspension or gearing for now... you might want to experiment with 
   these settings after you master driving.
 
5. Choose the OK Button (the button with a green check), to return to the Track 
   Select screen. Then choose the Next button to actually start the race.


DRIVING CONTROLS
----------------
The controls for driving the vehicle are configured in the Control Options screen.
The defaults are as follows:

	Up Shift 	- Joytick Button 1
 	Down Shift 	- Joystick Button 2
	Accelerate 	- Joystick forward
 	Brake 	- Joystick backward
	Turn Left 	- Joystick Left
	Turn Right 	- Joystick Right
	Change View - Spacebar

When the race first starts, your vehicle is in neutral gear. Even when driving an
automatic transmission, you still need to up-shift (once) in order to get into
drive. Once in drive, the transmission will automatically change gears for you.
If you get stuck and need to go into reverse, you need to down-shift twice. The
first down-shift will put you back in neutral, the second will get you into
reverse.  


COCKPIT CONTROLS
----------------
To PAUSE the game while racing, press either the "P" KEY or the "Esc" KEY. This
will bring up the paused menu. From the paused menu  you can do the following:

	Continue the race.
	Enter the garage to make changes to your vehicles setup.
	Terminate the race and return to the track select screen.

Other commands that are available while racing are as follows:

	"1" Key - Change the ground graphics detail.
	"2" Key - Change the road graphics detail.
	"3" Key - Change the vehicle graphics detail.
	"4" Key - Change the trackside object graphics detail.
	"5" Key - Change the sky graphics detail.
	"6" Key - Turn on/off all telemetry
	"7" Key - Turn on/off the map.
	"8" Key - Change the shadow graphics detail.
	"9" Key - Turn on/off the rear-view mirror.
	"0" Key - Turn on/off replay controls in the replay system.

	"R" Key - Ride with the next opponent.
	"T" Key - Return to your vehicle.
	"Z" Key - Move the camera forward  (in some camera views).
	"X" Key - Move the camera backward (in some camera views).
	"C" Key - Move the camera upward   (in some camera views).
	"V" Key - Move the camera downward (in some camera views).
	"B" Key - Move the camera left     (in some camera views).
	"N" Key - Move the camera right    (in some camera views).
	"A" Key - roll the camera          (in some camera views).
	"S" Key - roll the camera          (in some camera views).
	"D" Key - yaw the camera           (in some camera views).
	"F" Key - yaw the camera           (in some camera views).
	"G" Key - pitch the camera         (in some camera views).
	"H" Key - pitch the camera         (in some camera views).
	"K" Key - restore camera attitude  (in some camera views).



SETUP TIPS
----------

g-Force Analyzer:

The g-Force analyzer shows you how much traction your vehicle is getting. 
Before you suspect that SODA's handling is too slippery, check out the
values on this tool. A late model Corvette on pavement can corner at 
0.84 g's, a very respectable figure. A Trans-Am race car reportedly 
produced 1.15 g's in skid-pad testing.  The vehicles in SODA are 
cornering at or above these values, and they are racing on dirt and mud, 
not pavement. 

So if the corners still seem too slippery, you are probably driving too fast 
around the turns, and applying too much horse power, causing the backend to
lose all lateral traction. When turning, letting off the brake and gas will
allow all four tires to attain their maximum lateral traction. 

The g-Force analyzer is a tool for making setup changes to your vehicle. 
The analyzer shows the overall instananeous acceleration affecting
the vehicle's body in the forward/backward and left/right directions. The
number in the middle is how many g's (or earth gravitys) that the vehicle 
is feeling. The goal of setting up your vehicle is to maximize that value
when accelerating, braking, and turning.

To use the g-Force analyzer, turn it on in the garage. Then race a few laps
normally, without really paying any attention to it at all. After racing a
few laps, enter the replay system, and notice the average values obtained
while going around various turns (possibly you want to write these values 
down), and on various racing surfaces. For choosing tires, it may be enough
just to lock up the brakes on a straight away and note the value. Be aware
however, that different road surfaces on the same track will produce different
tractions and drags for different tires.

Next, enter the garage and tweak a setting, such as your tire type. For best
results just try adjusting one setting at a time. Repeat the above procedure
of racing a few laps, then entering the replay system to check the g-force
analyzer results. 

By comparing the results of the various trials, it should be possible for you 
to determine if the setup changes improved, degraded, or had no impact on the
vehicle's handling.  Also, you should record your lap times for each
trial, as the lap time is actually more important to you than how many
g's you can get in the corners. 

Also, be aware that the best setup in terms of g-Force, may not be best for
damage control. When setting up your vehicle you need to compromise between
handling and preventing damage. For instance, setting your springs soft may
lower the vehicle's center-of-gravity, and provide better traction, but it
may also cause the suspension to bottom out on bumps and jumps, bending or
breaking suspension components.

The g-Force analyzer can also help you analyze your driving technique. 
The value in the circle should stay as large as possible all of the time. To 
get best lap times, your vehicle should always be under large accelerations, 
either accelerating towards the next turn, braking before turning, or cornering 
during a turn. To win races the vehicle should never just be coasting near zero 
g's except when flying through the air. 

The primary way to tell if setup changes are helping or hurting is to race several
laps until your lap times stabilize at your best ability. Then change one setup
item, and repeat the procedure. Changing multiple items at once is not 
recommended because they may cancel each other out, or make it impossible to 
determine what really made the difference to the handling. 

Also, in the garage you can load/save your setups to disk. This is handy for
creating optimal setups for each track which can then be loaded during series
racing or multi-player races.


Horsepower:

The horsepower setting allows you to adjust your vehicle's power.  It would 
seem that setting this value to the maximum would be the best thing to do, 
but this is definitely not the case.  In some of the actual SODA racing 
classes there are rules about how much the vehicle must weigh per cubic 
inch of engine (such as 10 lbs/cubic inch).  Many racers use less horsepower 
than the maximum because they feel that the reduced vehicle weight gives 
them more of an advantage than some extra horsepower. 

In SODA Off-Road Racing, increasing the horsepower also increases the 
weight of the vehicle.  The extra weight may mean that you cannot take 
some corners as quickly, and it may also slightly reduce the acceleration 
and braking of the vehicle - you will not be able to get as many g's of traction.  

Weight reduction is not the only reason to reduce the horsepower.  If you set 
your power too high it may be excessively difficult to keep control of the 
vehicle.  When you have more power than traction, the effect is that the 
drive wheels easily "break loose" and spin, actually providing less acceleration 
then if they were gripping the road.  This wheel spin can be used to help 
slide the backend around turns (called throttle steer), but can also cause lots 
of spin-outs.   On twisty tracks, it is almost certainly better to reduce the 
horsepower from the maximum in order to achieve the best control and 
cornering power.  On the other hand, for tracks with long straight-aways, 
the extra power can really help the vehicle reach top speed quickly, 
greatly improving lap times. 

When first learning to drive, especially with the trucks, it is a good 
idea to drastically reduce the horsepower.  This will help you keep 
control of the vehicle while learning the controls and the tracks.


Transmission:

SODA Off-Road Racing allows you to select between an automatic 
or manual transmission.  The automatic transmission is easier to use 
because you only have to manually shift between reverse, neutral, 
and first gears.  Once you get into first gear, the transmission will 
automatically shift between all of the drive gears to keep the 
engine's RPM within the desired range.  When using a manual 
transmission you must manually shift between first, second, third, 
and fourth gears.   

The manual transmission has an advantage over the automatic 
transmission because it allows you to choose when to shift gears.  
The automatic transmission, while easier to drive, does not have 
the intelligence required to always shift at the optimum shift points, 
reducing the vehicle's acceleration from the maximum that might 
otherwise be obtained.


Tire Selection:

The following information may help you choose tires for each track and racing
environment. The numbers below are relative, and are not in any specific units.
The road surfaces in the country are dirt and mud. In the desert, they are gravel
and packed dirt, and in the tropics are mud and packed dirt. Typically, in each
enviroment, there is a trade-off between two tread types depending on the amount
of each of the two road surfaces on the track.  As a general rule, in the country
normal is good unless there is a lot of mud. In the desert, shallow is good, unless
the track is nearly all gravel. In the tropics, shallow is good, unless there is 
a lot of mud.  Also the wear on the surfaces off the road (not shown) are a lot 
higher than the road itself - spinning your tires on grass will quickly slice 
open your tires on an invisible sharp rock and cause a flat. Also the drags off 
the road (not shown) are quite high to help prevent racers from taking too many 
"short-cuts". 


  	             DEEP TREAD            NORMAL TREAD           SHALLOW TREAD
  SURFACE     Traction Drag  Wear	 Traction Drag Wear	   Traction  Drag  Wear     
  ---------------------------------------------------------------------------------
  DIRT           73      8    13	   82       6   11	     77       2      9
  MUD            80     25    11	   74      50    7	     70      65      5
  GRAVEL         75     20    11	   79      15    7	     73      10     19
  PACKED DIRT    72      8    15	   73      04    7	     80       2     11


To reduce tire wear:

	1. Avoid spinning your wheels too much.
	2. Don't run with excessive wheel camber.
	3. Don't push it too hard in the corners. 
	4. Don't hit bumps and jumps at top speed.


Camber:

A wheel's camber is the angle that the wheel is tilted. If the wheel is tilted 
in at the top, then the wheel has negative camber. If the wheel is titled
out at the top, then the wheel has positive camber.  A wheel's camber has
two main effects, tire wear and camber thrust. If a tire is not perpendicular
to the ground it will not wear evenly, so large camber angles will cause a
tire to wear out more quickly. Camber thrust is the lateral force produced when
a tire is run with a non-zero camber, and is in the direction of the tilt. 
A negative camber can therefore help a vehicle corner at higher speed, because
the camber thrust will be larger in the direction that the car is turning
due to weight transfer while cornering.  For wide street radials, the camber
forces tend to fall off at about 5 degrees. For motorcycle tires, the force 
can be useful up to over 40 degrees. For off-road racing trucks, the best
angle is probably somewhere between these two, but closer to the street 
radials.  

A vehicle's camber should be set to maximize cornering force as reported by
the g-force analyzer, but should be reduced if necessary to lessen wheel and
tire damage caused by jumps, bumps, and normal tread wear.  Also be aware that
the camber angle on the outside tires increases slightly in the positive direction 
when cornering, because the vehicle's body (and wheels) roll to the outside of 
the turn during cornering. 


Springs:

The springs are used to keep the tires in contact with a bumpy road as
much as possible. If the springs are set too soft the suspension will 
"bottom out" when landing from jumps and when hitting bumps, causing 
damage to the suspension and wheels. If the springs are set too stiff, the
vehicle's traction will suffer, and in this game the vehicle's center of 
gravity will be raised, causing less traction in turns, and making the 
vehicle easier to roll. Generally, the springs should be set as soft as 
possible for the best handling and traction.

SODA Off-Road Racing, like many Off-Road racing teams, relies on variable 
rate springs, which means that the spring rate increases as the spring is
compressed. This allows the vehicle to ride near the middle of the suspension 
travel at normal loads, while still being able to handle very large loads 
without bottoming out under extreme conditions. 

Setting the rear shocks/springs stiffer or softer than the front shocks/springs 
can adjust the vehicle's oversteer/understeer to a limited extent, but it cannot
overcome the oversteer cause by too much accelerator pedal. If suffering from 
severe oversteer, try reducing the vehicle's horse power before trying to fix
it by adjusting the springs. 


Shocks:

The shocks are used to dampen the springs. Without shocks, off-road
vehicles would bounce around on their springs like crazy, and be nearly
impossible to drive. In off-road races, shocks also help absorb the force 
from landing from large jumps or from hitting large bumps. If the shocks 
are set too soft, the springs will bottom-out too easily 
causing suspension and wheel damage. If the shocks are set too stiff, 
the shocks themselves will absorb too much impact and take damage. Try 
to balance the settings of the shocks and springs so that the shocks and
suspension take about equal damage when landing from large jumps, and set 
both the shocks and springs only as stiff as absolutely necessary to 
make it through the race with acceptable damage to the suspension.


Weight Distribution:

The Weight Distribution setting allows you to slightly move the 
vehicle's Center of Gravity (C.G.) forward (positive values) or  
backward (negative values).   Moving the C.G. can slightly affect 
the vehicle's handling.  

Moving the C.G. towards the rear of the vehicle may improve 
acceleration because the rear wheels will have more traction due 
to the increased load, helping deliver the power to the road.  At the 
same time, it will reduce the load on the front wheels, reducing their 
traction, which may lessen the cornering forces at the front of the vehicle.  
Moving the C.G. can also slightly affect how the vehicle takes jumps, 
but probably not as much as adjusting the shocks and springs.   

Configuring for an equal load (or as close as allowed by the vehicle's design) 
between the front and rear of the vehicle will provide optimal cornering 
power, but not necessarily optimal handling.   If the front or the rear has 
a higher share of the load, the cornering forces will be reduced due to an 
effect called "tire load sensitivity".   The tires of a vehicle produce the 
most total traction when they all share an equal portion of the total load.  
Whenever the load is transferred disproportionately to the various tires, 
the maximum traction of the vehicle is reduced. 


Gearing:

The gearing can make a huge impact on lap times. When gears are set too 
tall the vehicle has too large of a top speed, and its acceleration
suffers. Conversely, if set too small, the acceleration may be too large, 
causing the wheels to break lose too easily, and the engine will redline
in 4th gear. Generally, set the 4th gear over the top speed you 
expect to use on the track. For twisty tracks you probably want more 
acceleration and less top speed, so you would set 4th gear lower. For 
tracks with lots of long straight-aways, you probably want a higher 
top speed. If you are redlining the engine in fourth gear without 
wheel spin, you should probably set 4th gear higher. 

After setting fourth gear, run some laps and determine how 3rd gear should
be set to maximize lap times. 1st and 2nd gears are much less important
than 3rd and 4th gears, and are rarely used while racing.  

When adjusting gears you must insure enough overlap in the speed ranges of
each gear so that the automatic transmission can shift. For instance,
if the automatic transmission is not shifting from 2nd to 3rd gear (even
when redlined), then 3rd gear is probably too large. Overlapping the
gears is important for the manual transmission too, but will not prevent
shifting even if setup incorrectly.


Steering Lock:

The steering lock setting allows you to adjust how many degrees your 
front wheels turn when you turn the steering wheel as far as it will go to 
the right or the left.   Reducing the steering lock will give you more precise 
steering control but will also reduce how far you can turn the wheels. 

In off-road racing, a large steering lock is necessary to help you recover 
from slides and spins.  However, on some tracks (or with some joysticks) 
it may be desirable to slightly reduce the steering lock for better control 
on the straight-aways.  For most types of tires, the maximum cornering 
forces are achieved with less than twelve degrees of steering angle. 

Also, because tires produce cornering forces at right angles to the direction 
the wheel is pointing, turning the wheels very sharply will cause a large 
rearward drag force, drastically slowing the vehicle.  Turning the wheels 
past the optimum steering angle actually gives you less cornering force and 
increases drag - a double whammy.   Remember, turning the vehicle with the 
minimum required steering angle will help you maintain momentum through 
turns and will also help you keep better control of your vehicle.


DRIVING TIPS
------------
As in the real thing, many of the vehicles in SODA Off-Road Racing 
are over-powered. If you experience difficulty driving, try the 
following:

	- We strongly recommend that you drive with a high quality joystick 
        or a steering wheel/pedals combination. SODA Off-Road Racing features 
	  analog acceleration, braking and steering. Using the keyboard for 
        acceleration, braking, or steering is not recommended because 
        it does not allow you to easily specify how hard to accelerate, or 
        how hard to brake or turn. Controlling the slip of your drive wheels using 
        an analog gas pedal (such as an actual accelerator pedal, or a joystick) is 
        the most fundamental skill of off-road race driving. It is difficult (or 
        impossible) to perform this skill using a keyboard or a button. 

	- Reduce your vehicles horse-power in the garage to the minimum. 

	- Turn into the slide. If your backend slides to the right, turn right. 

	- Be very gentle with the accelerator. You only need to push the 
	  accelerator very lightly to match the power from a "floored" accelerator 
 	  of a normal car. 

	- Test your calibration from the calibration screen and make sure your 
	  input device is calibrated and working. A bad calibration can make it 
  	  impossible to control the amount of torque delivered to the rear wheels.

	- At first just try to drive 30 or 40 MPH until you master the track and
 	  vehicle. driving with 800 HP is much more challenging than driving a 
        normal passenger vehicle.

	- Always down-shift to first gear when starting from a stop. If you try to 
        get going in third or fourth gear it is difficult not to spin out again.

	- Try not to accelerate or brake much while turning. Acceleration and braking
        reduce the available traction for cornering. 

	- Make sure you have the appropriate tires for the track. Using mud tires
	  on gravel, or gravel tires on mud will cause the vehicle to have less
 	  cornering ability, and may make the road seem excessively slippery. Also,
  	  choosing the wrong tire in mud can dramatically increase drag.

	- Try not to lock the brakes when slowing down. Be gentle with the
	  joystick. When the wheels are locked up, all ability to steer the vehicle
	  is lost. Sometimes, if you brake too hard, quickly tapping the accelerator
        can get the tires back up to speed, and help you to regain control.

	- If the vehicle starts to get too sideways, immediately stop accelerating, 
	  and try down-shifting or lightly tapping the brakes. This sometimes helps 
   	  get the vehicle back under control. Acclerating when starting to slide
	  will usually cause the backend to "break loose" even more, insuring you
   	  completely spin-out!

	- Reduce graphics detail to get the best frame-rate that your system
	  can provide. When the graphics performance is slow or "jumpy" it 
	  makes it harder to drive. You want the animation to be as smooth as
	  possible.


Series Races:

Compete in the 12-race off-road Championship Series.  In Series Races 
you start out in Class 1, racing against novice drivers.  When you finish 
the season in first place, you have earned the right to upgrade your vehicle 
and advance to the next racing class.  The vehicle upgrades include: frame, 
tires, suspension, engine, and wheels.  There are six racing classes to 
master -- and you will be an off-road racing master when you are the 
season champion in Class 6.

Series Tracks:
After selecting the career from Active Careers on the Championship Series 
screen, the next track in the series is displayed.  In series racing the order 
of the tracks is already determined.  Perfect your setup in Practice before 
each race.

No Turning Back After the Checkered Flag:
As in real off-road racing, once the checkered flag is waving there is no 
turning back!  Be sure to take a few warm-up laps in Practice Mode.  There 
is no restart feature in Series Races.  When you cancel a series race it is 
considered to be a DNF (Did Not Finish) condition, and the results of that 
race are generated in accelerated time.

Series Schedule
---------------
The order of the tracks is fixed in championship series as follows:

	  1.  Cliffs of Fear
        2.  Desert Treat
        3.  Paradise Leap
        4.  Dragon's Claw
        5.  Strip Mine
        6.  Terrace Ledge
        7.  Figure 8
        8.  Devil's Bluff
        9.  Palm Valley
        10. Loop JumpOver
        11. Barren Lands
        12. Isle of Dread




Multi-Player Racing:


SODA Off-Road Racing provides multi-player support for several 
different communication methods, including LAN, modem, and direct serial connections. 

In all modes, one player first creates a new multi-player session.  Other players 
can then join the existing session.  The player that creates the session is called 
the "host" and has special privileges for controlling the session, such as choosing 
tracks, and starting and ending races.  

Multi-Player Requirements
�	Network: 	IPX or TCP/IP compatible network for 2-6 players.
	
�	Modem: 	Windows 95 compatible modem, 14,400 bps or faster, for 2 players.
	
�	Serial: 	Serial cable with a null modem, for 2 players.
	

Creating a Session:
One player creates a session (the host), other players may then join.  Typically, 
the player with the best performing PC should be the host because the host 
system has special responsibilities and performs extra tasks during the session.  
Using a poorly performing PC as the host can degrade game play for all of the 
players in the session.

To create a new multi-player session, click on "Multi-Player" from the Main Menu.  
The Select Medium screen appears.  Usually, only communication mediums that 
are actually available on your PC will appear.  For instance, if you do not have 
IPX installed, the IPX LAN mode may not appear as a selection.  Choose the 
desired communication medium, then click on the "Create Session" button.   
The Create Session screen appears. 

On the Create Session screen, select the desired vehicle type for the session, provide a 
name for the session (that the other players see when joining), and provide a player 
name.  After completing these entries, click on the Checkmark button to finish the 
creation process.  For the LAN based modes the session is now created, and the 
host is placed into the Multi-Player Chat screen. 

Note: If you are hosting a TCP/IP session, it may be necessary to give your IP address 
to other users to enable them to join your multi-player session. If you do not know 
your IP address, from the Windows 95 Start menu, click on Run, then type "winipcfg".  
Your IP address will be displayed in the IP Configuration dialog box.   

For modem and serial connections, a connection must first be accepted before 
proceeding to the Multi-Player Chat screen. 

Accepting a Modem Connection
1.	The Select Modem dialog box appears.  Select the desired modem  
	(14,400 bps or faster required).
	
2.    Click on the "Config" button, which brings up the Windows 95
	properties sheet for your selected modem.
	
3.    The properties sheet may vary for different modems, but the options 
	you should set relate to error control and flow control.  For some modems 
	these check boxes can be accessed by switching to the "Connection" tab of 
	the Properties sheet, and then clicking on the "Advanced..." button.  Turn 
	off error control and flow control. 

4.    Keep clicking on the "OK" buttons until the modem's Property sheet 
	goes away, and you return to the Select Modem dialog box.
	
5.    Click on the Checkmark button and a message box appears with the
	message "waiting for call...".  When the remote player calls your modem, 
	it should automatically answer and take you to the Multi-Player Chat screen. 

Accepting a Serial Connection
1.    The Select Port dialog box appears.  Select the desired communication 
	port that is connected to the remote system (requires a serial cable 
	with a null modem).
	
2.    Click on the Checkmark  button.  This should immediately take you 
	to the Multi-Player Chat screen, where you can wait for the other player to join. 


Joining a Session:

After a session has been created by the host of the session, other players 
may join the session.  To join an existing multi-player session, click on 
"Multi-Player" from the Main Menu.  The Select Medium screen appears.  
Usually, only communication mediums that are actually available on your 
PC will appear.  For instance, if you do not have IPX installed, the IPX LAN 
mode may not appear as a selection.  Choose the desired communication 
medium, then click on the "Join Session" button. 

Joining a TCP/IP Session
After pressing the "Join Session" button, a Windows 95 dialog box appears 
asking you to supply the computer name or IP address of the host that created 
the session.  Over a LAN, the game will sometimes be able to find the host 
even if you leave the name blank.  But if this does not work, or if playing 
over a Wide Area Network (WAN) with sub-nets and routers, it will be 
necessary to enter the computer's hostname or IP address. 

Click on the "OK" button.  Once any sessions are located, the Select Session 
screen will appear, allowing you to choose the multi-player session you wish 
to join from a list of the available sessions on your LAN.  Select the desired 
session and enter your player name.  Click on the Checkmark button to join 
the session.  This takes you to the Multi-Player Chat screen.

Joining an IPX Session
When you press the "Join Session" button, your computer will search the 
local network for any sessions.  It will not search across routers, so if 
you are really playing over a Wide Area Network with routers and 
sub-nets, you will need to use TCP/IP instead of IPX.  

If any available sessions are located on your LAN, the Select Sessions 
screen appears.  Select the desired session and enter your player name.  
Click on the Checkmark button to join the session.  This takes you to 
the Multi-Player Chat screen.


Joining a Modem Session
1.    When joining a Modem Session, the Dial Modem Session dialog 
	box appears.  Select the desired modem from the list of available 
	modems (14,400 bps or faster is required).  
	
2.	Click on the "Config" button, which brings up the Windows 95 properties 
	sheet for your selected modem.
	
3.	The Properties sheet may vary for different modems, but the options
	you should set relate to error control and flow control.  For some 
	modems these check boxes can be accessed by switching to the 
	"Connection" tab of the Properties sheet, and then clicking on the 
	"Advanced..." button.  Turn off error control and flow control. 
	
4.	Keep clicking on the "OK" buttons until the modem's Property 
	sheet goes away and the Select Modem dialog box appears.
	
5.    Enter the phone number to dial into the "Opponent's Phone
	Number."  If the opponent is already listed in your phone book, 
	or if you wish to add the opponent to the phone book, click on the 
	"Phone book" button at this time.  Add the opponent to the available 
	choices or select from one already present.  Click on the Checkmark 
	button to select the desired opponent from the Phone Book dialog box.  
	
6.	Fill in your player name on the Dial Modem Session dialog box.
	
7.    Click on the Checkmark button to dial the host's system.  After 
	the modems successfully connect, both players will be taken to the 
	Multi-Player Chat screen.

NOTE: When entering phone numbers the following special characters can be 
used to control how the number is dialed:

�	"!" Indicates that a hookflash (one-half second onhook, followed 
	by one-half second offhook before continuing) is to be inserted in 
	the dial string. 
	
�	"P" Indicates that pulse dialing is to be used for the digits following it. 
	
�	"T" Indicates that tone (DTMF) dialing is to be used for the 
	digits following it. 
	
�	"," Indicates that dialing is to be paused.  Multiple commas can be 
	used to provide longer pauses. 
	
�	"W" Indicates that dialing should proceed only after a dial tone 
	has been detected. 
	
�	"@" Indicates that dialing is to "wait for quiet answer" before dialing 
	the remainder of the dialable address.  This means to wait for at least one 
	ringback tone followed by several seconds of silence. 
	
�	"$" Indicates that dialing the billing information is to wait for a 
	"billing signal" (such as a credit card prompt tone). 


Joining a Serial Session
1.  When joining a Serial Session, the Connect Over Communication 
    Port dialog box appears.  Select the communication port that is 
    connected to the remote system (requires a serial cable with a null modem).
	
2.  Enter your player name.
	
3.  Click on the Checkmark button to join the session.  The Multi-Player Chat 
    screen appears.
	

The Multi-Player Chat Screen
The Multi-Player Chat screen is the first screen you see after creating 
or joining a multi-player session.  Players can send messages to the 
other joined players by typing a message into the send box and then pressing enter.   

At the top of the screen is a list of all players that are currently joined 
in the session.  Once a race has ended, the position column displays the 
finishing positions for each player that participated in the race.  When 
new players join, this field may sometimes be set to a dash until they 
have participated in a race. 

When the host (or master) of the multi-player session is satisfied 
with the list of joined players, the host can start the next race by 
clicking on the Checkmark button.  Players that have joined the race 
must wait until the master decides to start the next race.  When the 
next race is started all players go to the Multi-Player Select Track 
screen simultaneously.

When the race is over for a player, the player returns to the 
Multi-Player Chat screen to wait for the next race to begin.  If a 
race is still in progress, a TV Camera view of the current race will 
appear in the upper-right corner of the screen.  Clicking on the 
Car button makes the TV Camera switch to a different vehicle 
that is still racing. 

Multi-Player Races
When the host decides to start the next race all players switch to 
the Multi-Player Select Track screen.  For all joined players the 
screen is in a read-only mode, only the host may select the track.  
As the host switches to various tracks, the track screen also updates 
on all of the remote player's systems.  When the host clicks on the 
Checkmark button, all player's systems load the selected track and 
then display the Race Start Menu. 

The Race Start Menu gives each player an opportunity to enter the 
garage and make changes to their vehicle's setup before entering the 
race.  A countdown timer appears showing how much time remains 
before the race starts.  Click on the "Garage" menu pane to enter the 
garage to make setup changes to your vehicle.  One strategy for this 
screen is to already have your setups ready to go and saved to disk, 
then you can simply (and quickly) load the desired setup for the current track. 

Once your vehicle is correctly set up for the race, exit the garage and 
click on the "Enter Race" menu pane.  This causes your vehicle to be 
registered and present in the race.  Once all players have entered the 
race, or if the countdown timer reaches zero, the race will begin.  
Players who have not yet entered the race when the countdown timer 
reaches zero will be left behind at the starting line, but they can 
still enter the race.

When the host finishes the race and returns to the Multi-Player Chat 
screen, the host can click on the "End Race" button to prematurely 
end the race.  This button starts a count-down timer to end the race, 
visible to all players that are still racing.  The race ends and all players 
are returned to the chat screen when this count-down timer reaches zero, 
or whenever the race ends  for all of the participating players.

If a player joins a session while a race is already in progress, the 
new player will remain at the Multi-Player Chat screen until the 
current race ends and the next race begins.


Solving Modem Problems
To use a modem for a multi-player connection, you need to make 
sure that error control and flow control are disabled.  These 
settings can usually be found in the modem properties.  Go to 
the Control Panel, then Modems.  Select your modem and choose 
Properties.  Select the "Connection" tab and click on the 
"Advanced" button.  Turn off the check-boxes for flow control 
and error correction.  

The game will only work properly with a 14.4 Kbps or better 
connection, 9600 baud is not supported.  If you have problems 
connecting or playing, you may be able to solve the problem by 
checking "record a log file" option on the same modem properties 
dialog where you turn off error correction and flow control.  The 
log file is written into your windows directory into a file named 
"modemlog.txt".  In this log you can see all of the modem initialization 
strings and any responses from the modem, including the connection 
speed.  One common problem is that some high-speed modems can 
end up connecting at a low speed due to incompatibilities with each 
other.  For instance, two 28.8 kbps modems sometimes negotiate a 
connection of only 9600 bps.  This type of problem can be detected 
by turning on the modem log file option and then looking at the 
modemlog.txt file.  The actual connect speed is usually reported 
in this file.


FRAME RATE TIPS
---------------
Any or all of following suggestions can help improve the game's frame rate 
on many PCs:

	- Turn off the rear-view mirror. The track map overlay may be more 
	  useful anyway, and has a negligable impact on frame rate.

	- Turn off translucency in the graphics detail settings (for shadows,
 	  etc.)

	- Lower graphics detail settings. Just turning off the texture mapped
	  sky can make a large difference on some PCs. 

	- Race with fewer opponent vehicles. Each car consists of over 500
	  polygons.

	- Do not race in cockpit view. Bumper-Cam has the best performance
        because most of your car does not appear in the view, reducing the
	  number if polygons that need to be rendered each frame.

	- Race in the lower resolution 320x200 mode instead of the maximum 
	  640x480 mode.

SCREEN SHOTS and <Alt> Key
--------------------------
Hitting the <Alt> key will cause the game to freeze (during game-play and screen-play). 
To unfreeze the game, hit <Alt> again.  This is standard Windows95 behavior for
an application and allows for several <Alt> sequences:

	<Alt-F4>  	 Terminate the application
      <Alt-Tab> 	 Switch between running applications
	<Alt-PrtScr> Copy a screen-shot to the Windows 95 clipboard.

Hitting <Alt> or <Alt-Tab> while racing pauses the simulation so that play may resume 
when the application is reactivated.

Windows 95 also allows you to capture the contents of the current window by hitting
<Alt+PrtScr> keys. This copies the window to the clipboard. You can then open
Paint (from the Windows95 accessories folder) and paste the picture you captured. Then 
you can save the picture as a bitmap.  Normally, you need to have your display 
settings set to 256 color for this to work correctly. However, when using a Rendition 
board, you need to have your display settings set to 16-bit color (High Color) for 
this to capture the colors correctly (it also produces a larger bitmap file - but it
looks better than the 256 color version). 


PAGE FAULTS
-----------
On systems with less than 32 MB of RAM, the system may sometimes page
fault. The main symptom of this is the disk drive running while racing, 
or short pauses while racing, where the system locks up for a fraction of a
second. This is due to the options you have selected requiring too much 
memory. The following tips can help solve the problem:

	- Make sure no other applications are running.

	- Reduce the replay system capacity to 2 minutes, or turn it off in
	  the options.  (Saves up to 1MB of RAM).

	- Turn off the radio voice (Saves 2MB of RAM) in the options. This 
	  especially improves multi-player races on 16MB systems and track 
	  load time.

	- Turn off damage in the options. This keeps the body panels from 
	  having to load into memory.

	- Race with fewer opponents. Fewer car textures and car body objects
        need to be loaded into memory.

	- Reduce the graphics detail. The textures will swap out of system
	  memory and the page faults (if any) will quickly subside.



IV] KNOWN PROBLEMS
=======================================================================
Video

Low-Res mode (320x240) does not work correctly on some video cards. 
The symptom is the game running in the upper-left corner of the screen, 
instead of the display actually switching to the proper resolution. This
problem has mainly been reported on some Matrox Mystique and some Matrox
Millennium video cards.

Hi-Res mode (640x480) may not display properly on machines with graphics 
accelerators based on the Tseng Labs, Inc. ET6000.

Sound

If you have a Yamaha OPL3-SAx sound card you may not be able to adjust the
volume of the CD audio from the Options menu in SODA Off-Road Racing. If
you are having this problem you should adjust the volume from the mixer
control panel. You can usually reach the mixer control panel by double
clicking on the sound icon on the toolbar. See the manual for your
soundcard for instructions on how to use the mixer control if you have difficulty.

Graphics

Changes made to the graphics options using the keyboard controls (1-9) will not 
be retained after exiting the track at which the changes were made.  The 
settings will always default back to those set on the Graphics Options screen.  
Use the Graphics Options screen to set your preferred level of detail if you 
wish to avoid having to reset the detail settings upon entering each track.

The suspension/gauges detail setting on the Graphics Options screen is not labeled.  
It lies just beneath the setting labeled "Vehicle".

Driving

Your vehicle may be accelerated to unusually high speeds following a violent 
collision, such as jumping into a wall.

Multi-player

Game speed on one or more machines may be increased to twice its norm in a 
multi-player game. Once this state occurs, the affected PC should be rebooted
to correct the problem. 

Control Options

Inverted left/right joystick control settings made in the Control Options menu 
will not be recognized in the game.  The left/right controls will work as if 
they had not been inverted.

Track Analysis

It is possible to create a track that will take an excessively long time 
to learn.  It is also possible that the program will not be able to learn a 
track that you create at all. If the learning trial count gets over 100,000
while learning a track, you probably need to simplify the track. 

Track Designer

The number of objects, puddles, fences, and cameras that can be placed on a 
track is limited.  If you have trouble adding objects or cameras to a track, 
try deleting one or more of the less important ones.

The number of control points for puddles and fences that can be placed on a 
track is limited.  If you have trouble adding control points for puddles 
and fences to a track, try deleting any unnecessary control points.

The number of detachments that can be placed on a track is limited.  If you 
have trouble detaching vertices on a track, you have reached the limit.

The program may crash while generating if too many objects are placed on a 
single grid square of a track.

If you increase the width of a track that is against a wall and click on a 
road control point near that wall, the track will snap back to its default 
shape. Be sure to save your track file before attempting to click on a 
road control point after increasing the road width.

World Wide Ranking Client

If you try to connect to the World Wide Ranking Server prior to generating 
any records on any tracks, you will receive a "Lost connection to the
server" error message.

=======================================================================
Customer Service Support and Sales

United States
Sierra Direct			U.S.A. Sales Phone: (800) 757-7707
7100 W. Center Rd			International Sales:  (425) 746-5771 
STE 301				Hours: Monday-Saturday 7AM to 11 PM CST, Sundays 8 AM to 9PM CST
Omaha, NE  68106	 		FAX: (402) 393-3224

United Kingdom
Sierra On-Line Limited		Main: (0118) 920-9111
2 Beacontree Plaza,		Monday-Friday, 9:00 a.m. - 5:00 p.m.
Gillette Way,			Fax:   (0118) 987-5603
Reading, Berkshire		Disk/CD replacements in the U.K. are �6.00,
RG2 0BS United Kingdom		or �7.00 outside the UK. Add "ATTN.: Returns."

France
Parc Tertiaire de Meudon	Phone: (01) 46-01-48-53
Immeuble "Le Newton"		Lundi au Vendredi de 9h � 18h 
25 rue Jeanne Braconnier 	Fax: (01) 46-30-00-65
92366 Meudon La For�t Cedex
France

Germany
Sierra Coktel Deutschland	Tel: (0) 6103-99-40-53
Robert-Bosh-Str. 32		Montag bis Freitag von 10h - 17Uhr
D-63303 Dreieich			Fax: (0) 6103-99-40-35
Germany

On-Line Sales
Internet USA:			http://www.sierra.com
Internet United Kingdom:	http://www.sierra-online.co.uk
Internet France:			http://www.sierra.fr
Internet Germany:			http://www.sierra.de





THE SIERRA NO-RISK GUARANTEE
The Promise: We want you to be happy with every Sierra product you purchase from us. 
Period. If for any reason you're unhappy with the product, return it within 30 days 
for an exchange or a full refund...EVEN IF YOU BOUGHT IT RETAIL. (Hardware ordered 
direct must be returned within ten days.)

The Only Catch: You've got to tell us why you don't like the game. Otherwise, we'll 
never get any better. Send it back to us and we promise we''ll make things right. 
(If you bought it at a retail outlet, please send your original sales receipt.)
 * Returns valid in North America only.

Disk and or Manual Replacement:		Product Returns:*
Sierra On-Line Fulfillment			Sierra On-Line Returns
4100 West 190th Street				4100 West 190th Street
Torrance, CA  90504				Torrance, CA  90504	 
	
NOTE: To replace your disk(s) please send only Disk #1 (or the CD) and copy of your dated 
Receipt, if less then 90 days.  After 90 days please include a $10 handling fee along 
with Disk / CD #1.  For Documentation, please include a $ 5.00 handling fee and a 
photocopy ONLY of disk #1.  Payment should be made at the time of your request.  
Sorry, no credit cards.
* Returns to this address valid in North America only.

Technical Support

Automated Technical Support Line - USA:
1-425-644-4343			
Sierra On-Line offers a 24-hour Automated Technical Support line with recorded 
answers to the most frequently asked technical questions. To access this service, 
call (425) 644-4343, and follow the recorded instructions to find your specific 
topic and resolve the issue. If this fails to solve your problem, you may still 
write, or fax us with your questions, or contact us via our On-Line services.

U.S. Technical Support
Sierra On-Line				Main: (425) 644-4343
Technical Support				Monday-Friday, 8:00 a.m. - 4:45 p.m. PST 
P.O. Box 85006				Fax:   (425) 644-7697
Bellevue, WA 98015-8506		
				
Automated Technical Support Line - United Kingdom:
(0118) 920-9111
Sierra On-Line UK offers a 24-hour Automated Technical Support line with recorded 
answers to the most frequently asked technical questions. To access this service, 
call (0118) 920-9111, and follow the recorded instructions to find your specific 
topic and resolve the issue. If this fails to solve your problem, you may still 
write, or fax us with your questions, or contact us via our Internet or 
CompuServe sites.

U.K. Technical Support
Sierra On-Line Limited		Phone: (0118) 920-9111
2 Beacontree Plaza,		Monday-Friday, 9:00 a.m. - 5:00 p.m.
Gillette Way,			Fax:   (0118) 987-5603
Reading, Berkshire
RG2 0BS United Kingdom

France
Parc Tertiaire de Meudon	T�l�phone: 01-46-01-46-50
Immeuble "Le Newton"		Support Technique automatis� 7 jours sur 7 24h/24
25 rue Jeanne Braconnier	Techniciens accessibles du Lundi au Vendredi de 10h � 19h
92366 Meudon La For�t Cedex	Fax: 01-46-30-00-65
France

Germany
Sierra Coktel Vision Deutschland	Phone: (0) 6103-99-40-40
Robert-Bosh-Str. 32			Montag bis Freitag von 9 - 19Uhr
D-63303 Dreieich				Fax: (0) 6103-99-40-35
Deutschland					Mailbox: (0) 6103-99-40-41

Spain
Coktel Educative Multimedia		Tel�fono: (01) 383-2623
Avenida de Burgos 9			Lunes a Viernes de 9h30 a 14h y de 15h a 18h30
1�-OF2					Fax: (01) 381-2437
28036 Madrid
Spain

Italy						Contattare il vostro distribotore.


Sierra Warranty 

You are entitled to use this product for your own use, but may not copy, 
reproduce, translate, publicly perform, display, or reduce to any 
electronic medium or machine- readable form, reproductions of the software 
or manual to other parties in any way, nor sell, rent or lease the product 
to others without prior written permission of Sierra and Software Allies.  
You may use one copy of the product on a single computer.  YOU MAY NOT 
NETWORK THE PRODUCT OR OTHERWISE INSTALL IT OR USE IT ON MORE THAN ONE 
COMPUTER AT THE SAME TIME.

UNAUTHORIZED REPRESENTATIONS: SIERRA AND SOFTWARE ALLIES WARRANT ONLY THAT 
THE PROGRAM WILL PERFORM AS DESCRIBED IN THE USER DOCUMENTATION. NO OTHER 
ADVERTISING, DESCRIPTION, OR REPRESENTATION, WHETHER MADE BY A SIERRA DEALER, 
DISTRIBUTOR, AGENT, OR EMPLOYEE, SHALL BE BINDING UPON NEITHER SIERRA NOR 
SOFTWARE ALLIES OR SHALL CHANGE THE TERMS OF THIS WARRANTY.

IMPLIED WARRANTIES LIMITED: EXCEPT AS STATED ABOVE, SIERRA AND SOFTWARE ALLIES 
MAKE NO WARRANTY, EXPRESS OR IMPLIED, REGARDING THIS PRODUCT. SIERRA AND 
SOFTWARE ALLIES DISCLAIM ANY WARRANTY THAT THE SOFTWARE IS FIT FOR A PARTICULAR 
PURPOSE, AND ANY IMPLIED WARRANTY OF MERCHANTABILITY SHALL BE LIMITED TO THE 
NINETY (90) DAY DURATION OF THIS LIMITED EXPRESS WARRANTY AND IS OTHERWISE 
EXPRESSLY AND SPECIFICALLY DISCLAIMED. SOME STATES DO NOT ALLOW LIMITATIONS 
ON HOW LONG AN IMPLIED WARRANTY LASTS, SO THE ABOVE LIMITATION MAY NOT APPLY 
TO YOU.

NO CONSEQUENTIAL DAMAGES: NEITHER SIERRA NOR SOFTWARE ALLIES SHALL BE LIABLE FOR 
SPECIAL, INCIDENTAL, CONSEQUENTIAL OR OTHER DAMAGES, EVEN IF SIERRA OR 
SOFTWARE ALLIES ARE ADVISED OF OR AWARE OF THE POSSIBILITY OF SUCH DAMAGES. 
THIS MEANS THAT NEITHER SIERRA NOR SOFTWARE ALLIES SHALL BE RESPONSIBLE OR LIABLE 
FOR LOST PROFITS OR REVENUES, OR FOR DAMAGES OR COSTS INCURRED AS A RESULT OF 
LOSS OF TIME, DATA OR USE OF THE SOFTWARE, OR FROM ANY OTHER CAUSE EXCEPT THE 
ACTUAL COST OF THE PRODUCT. IN NO EVENT SHALL SIERRA'S OR SOFTWARE ALLIES'S
LIABILITY EXCEED THE PURCHASE PRICE OF THIS PRODUCT. SOME STATES DO NOT ALLOW 
THE EXCLUSION OR LIMITATION OF INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE 
ABOVE LIMITATION OR EXCLUSION MAY NOT APPLY TO YOU.





